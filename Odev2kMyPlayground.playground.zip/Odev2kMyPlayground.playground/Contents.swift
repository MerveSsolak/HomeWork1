import UIKit
import Foundation

class Odev2 {
    
    func ölcüm (tc:Double) -> Double {
        let sonuc = tc*1.8+32
        return sonuc
   }
    func dikdörgen(a:Double,b:Double) -> Double {
        let sonuc2 = 2 * a+2 * b
        return sonuc2
    }
    
    func içAçi(n:Int) -> Int {
        let sonuc4 = (n-2) * 180
        return sonuc4
}
    func kota(a:Int) -> Int {
        if (a>50) {
         print((a-50) * 4 + 100)
        }else {
        print(100)
        }
    
        return toplam
}
   
    func faktoriyel(number:Int) -> Int {
        if number == 0{
            return 1
        }
        return number * faktoriyel(number: number-1)
        
    }
    func saat(x:Int) -> Int {
        if (x<=160) {
         print(10 * x)
        }else {
        print(1600 + 20 * (x-160))
        }
    
        return 0
}
    

    func harfSayisi (kelime:String, harf:Character){
    var sayi = 0
    for letter in kelime {
        if letter == harf {
        sayi+=1
    
        }
    }
        print(sayi)
}
}
let a = Odev2()
a.ölcüm(tc: 12.2)
let sonuc = a.ölcüm(tc: 12.2)
print(sonuc)

let x = Odev2()
x.dikdörgen(a: 12.2, b: 20.0)
let sonuc2 = x.dikdörgen(a: 12.2, b: 20.0)
print(sonuc2)

let t = Odev2()
t.içAçi(n: 4)
let sonuc4 = t.içAçi(n: 4)
print(sonuc4)

let h = Odev2()
let toplam = h.kota(a: 0)

let m = Odev2()
m.saat(x: 149)

let b = Odev2()
b.faktoriyel(number: 10)
let sonuc6 = b.faktoriyel(number: 10)
print("Faktoriyel :\(sonuc6)")

let f = Odev2()
f.harfSayisi(kelime:"merhaba", harf: "a")








